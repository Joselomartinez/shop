﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Data;
using Business_Logic.BL;

namespace Shop.Controllers
{
    public class productsController : Controller
    {
        productBL obj = new productBL();

        // GET: products
        public ActionResult Index()
        {
            List<product> result = null;
            try
            {
                result = obj.listProduct();
            }
            catch (Exception)
            {

                throw;
            }
            return View(result);
        }


        public ActionResult Details(int? id)
        {
            product result = null;

            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                result = obj.productById(id);

                if (result == null)
                {
                    return HttpNotFound();
                }
            }
            catch (Exception)
            {

                throw;
            }

            return View(result);
        }

        // GET: products/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: products/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id_product,name,price")] product product)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    obj.Create(product);
                    return RedirectToAction("Index");
                }
            }
            catch (Exception)
            {
                throw;
            }

            return View(product);
        }

        // GET: products/Edit/5
        public ActionResult Edit(int? id)
        {
            product result = null;
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                result = obj.Edit(id);

                if (obj == null)
                {
                    return HttpNotFound();
                }

            }
            catch (Exception)
            {
                throw;
            }
            return View(result);
        }

        // POST: products/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id_product,name,price")] product product)
        {
            if (ModelState.IsValid)
            {
                obj.Edit(product);
                return RedirectToAction("Index");
            }
            return View(product);
        }

        // GET: products/Delete/5
        public ActionResult Delete(int? id)
        {
            product result = null;

            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                result = obj.Delete(id);

                if (result == null)
                {
                    return HttpNotFound();
                }
            }
            catch (Exception)
            {
                throw;
            }

            return View(result);
        }

        // POST: products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                obj.DeleteConfirmed(id);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                throw;
            }
        }

        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing)
                {
                    obj.Dispose(disposing);
                }
                base.Dispose(disposing);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
