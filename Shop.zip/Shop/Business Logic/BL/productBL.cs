﻿using Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Business_Logic.BL
{
    public class productBL
    {
        private shopEntities db = new shopEntities();

        public List<product> listProduct()
        {
            List<product> result = null;
            try
            {
                result = db.product.ToList();
            }
            catch (Exception)
            {
                throw;
            }

            return result;

        }

        public product productById(int? id_product)
        {
            product result = null;

            try
            {
                if (id_product != null)
                {
                    result = db.product.Find(id_product);
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        public void Create(product product)
        {
            try
            {
                db.product.Add(product);
                db.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public product Edit(int? id_product)
        {
            product result = null;

            try
            {
                if (id_product != null)
                {
                    result = db.product.Find(id_product);
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        public product Edit(product product)
        {
            product result = product;
            try
            {
                db.Entry(product).State = EntityState.Modified;
                db.SaveChanges();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public product Delete(int? id_product)
        {
            product result = null;
            try
            {
                if (id_product != null)
                {
                    result = db.product.Find(id_product);
                }                                
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        public void DeleteConfirmed(int id_product)
        {
            try
            {
                product product = db.product.Find(id_product);
                db.product.Remove(product);
                db.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void Dispose(bool disposing)
        {
            try
            {
                if (disposing)
                {
                    db.Dispose();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}